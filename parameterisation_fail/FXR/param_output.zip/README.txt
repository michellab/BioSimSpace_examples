# Antechamber was run with the following command:
/home/ppxasjsm/Software/amber18//bin/antechamber -at 1 -i antechamber.pdb -fi pdb -o antechamber.mol2 -fo mol2 -c bcc -s 2
